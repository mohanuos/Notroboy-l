# NRB Launcher V3

This is a legal scaffold for an NRB-branded launcher based on Zalith Launcher 2.
Replace the upstream source by forking Zalith Launcher 2 and apply the NRB branding.
Keep the GPL-3.0 license notices from the upstream project.
